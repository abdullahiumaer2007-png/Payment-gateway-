(function () {
  var s = document.createElement('script');
  s.src = './public/standalone.js';
  document.body.appendChild(s);
})();
